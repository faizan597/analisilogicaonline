
import spacy
from flask import Flask, request, jsonify
from flask_cors import CORS

nlp = spacy.load("it_core_news_sm")
app = Flask(__name__)
CORS(app)

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    sentence = data.get("sentence", "")

    doc = nlp(sentence)

    soggetto = None
    predicato = None
    tipo_predicato = None
    complemento_oggetto = []
    complemento_tempo = []
    complemento_luogo = []
    complemento_causa = []
    complemento_compagnia = []
    frase_tipo = "nominale"
    is_complessa = False

    for token in doc:
        if token.dep_ == "nsubj" and not soggetto:
            soggetto = token.text

        if token.dep_ in ["ROOT", "root", "cop"] and not predicato:
            if token.pos_ in ["VERB", "AUX"]:
                predicato = token.text
                tipo_predicato = "verbale"
            elif token.dep_ == "cop":
                predicato = token.text
                tipo_predicato = "nominale"

        if token.dep_ == "obj":
            start = token.left_edge.i
            end = token.right_edge.i + 1
            full_phrase = doc[start:end].text
            complemento_oggetto.append(full_phrase)

        if token.dep_ == "obl":
            phrase = doc[token.left_edge.i:token.right_edge.i+1].text
            if token.head.lemma_ in ["andare", "venire", "tornare", "arrivare", "uscire", "essere", "restare"]:
                complemento_luogo.append(phrase)
            elif token.head.lemma_ in ["avere", "fare", "essere", "accadere", "succedere"]:
                complemento_tempo.append(phrase)
            else:
                if "a causa" in phrase or "perché" in phrase:
                    complemento_causa.append(phrase)

        if token.dep_ == "obl" and any(child.text.lower() == "con" for child in token.children):
            phrase = doc[token.left_edge.i:token.right_edge.i+1].text
            complemento_compagnia.append(phrase)

        if token.dep_ in ["mark", "cc", "conj"]:
            is_complessa = True

    if predicato:
        frase_tipo = "complessa" if is_complessa else "semplice"

    result = {
        "frase": sentence,
        "soggetto": soggetto,
        "predicato": predicato,
        "tipo_predicato": tipo_predicato,
        "frase_tipo": frase_tipo,
        "complemento_oggetto": complemento_oggetto,
        "complemento_tempo": complemento_tempo,
        "complemento_luogo": complemento_luogo,
        "complemento_causa": complemento_causa,
        "complemento_compagnia": complemento_compagnia
    }

    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
